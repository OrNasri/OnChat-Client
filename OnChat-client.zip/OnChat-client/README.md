# ON Chat

# README FILE

# Run the project:
- Please first install the following packages:
* npm install react-bootstrap
* npm install react-router-dom
* npm install @microsoft/signalr
- Now run the following:
1. Run the ASP.NET project (the server project).
2. Run the rates project. (if you want to rate our chat).
3. Run the react project.

In order to register as a user at the signUp page you should create a user with the following details:
- username
- nickname
- password : must contain a lowercase letter, uppercase letter, number and minimum 8 charcters.

The port number of the api project server should be # [https://localhost:7242](https://localhost:7242/) #.

There are few more users registered to our chat.
Their login informations are:
1. - Username: or
   - Password: Nn123456

2. - Username: dani
   - Password: Nn123456

3. - Username: bob
   - Password: Nn123456

3. - Username: noa
   - Password: Nn123456

When you log into our chat you can open yourself chats page with friends that are also registers.
also you can chat with users from other servers - by click on the button with the man icon and fill the fields : username, nickname and server in format - localhost:XXXX, for example: localhost:7242 

You can assist the swagger page (the ASP.NET project) in order to check all features.


Enjoy!
